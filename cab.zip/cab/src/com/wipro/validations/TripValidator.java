package com.wipro.validations;

import com.wipro.bean.CabBean;
import com.wipro.userexceptions.NegativeKilometerException;

public class TripValidator {
	public static String printBillAmount(CabBean cabbean) throws NegativeKilometerException {
		String s;
		s=cabbean.getBookingID().substring(2);
		if(!(cabbean.getBookingID().startsWith("AD")&&s.matches("[0-9]+")&&s.length()==5))
		{
			return "Invalid Booking ID";
		}
		else
		{
			if(!(cabbean.getUserID()>1000&&cabbean.getUserID()<1501))
			{
				return "Invalid User ID";
			}
			else
			{
				if(!(cabbean.getCabType().equals("Tata Indica")||cabbean.getCabType().equals("Tata Indigo")||cabbean.getCabType().equals("BMW")||cabbean.getCabType().equals("Logan")))
				{
					return "Invalid Cab Type";
				}
				else
				{
					if(Integer.parseInt(cabbean.getKmsUsed())<0)
					{
						throw new NegativeKilometerException();
					}
					else
					{
						int[] a=amountGenerator(Integer.parseInt(cabbean.getKmsUsed()),cabbean.getCabType());
						return "Total Amount : "+a[1]+" , Receipt ID : "+a[0];
					}
				}
			}
		}
		
	}
	public static int[] amountGenerator(int kmsUsed, String cabType)
	{
		int[] array = {0,0};
		
		array[0]=(int) (Math.round(Math.random() * 89999) + 10000);
		
		
		if(cabType.equals("Tata Indica"))
		{
			array[1]=12*kmsUsed;
		}
		if(cabType.equals("Tata Indigo"))
		{
			array[1]=10*kmsUsed;
		}
		if(cabType.equals("BMW"))
		{
			array[1]=45*kmsUsed;
		}
		if(cabType.equals("Logan"))
		{
			array[1]=31*kmsUsed;
		}
		return array;
	}
}
