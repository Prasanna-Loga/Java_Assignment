package com.wipro.userexceptions;

public class NegativeKilometerException  extends Exception{
	public String toString() {
		
		return "Invalid KM";
	}
}
